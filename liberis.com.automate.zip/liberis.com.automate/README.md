# liberis_automation using C# with Specflow

This is a sample automation testing project
with a url to its home page and then on clicking 
"Get a demo" button it is required that it should shift to 
the next partner's page (https://www.liberis.com/become-a-partner).

Then there are three options on "Type of partner", 
so if none of them are selected then this msg should come
"Please select a type of partner".
